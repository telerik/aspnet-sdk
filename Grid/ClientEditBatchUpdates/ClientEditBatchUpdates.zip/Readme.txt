The following example demonstrates how you can switch grid cells in edit mode by simply double-clicking
them, update the data on the client and then process
all changes on the server with a single batch update. This demo illustrates how
this can be accomplished using client scripts. Note that this approach is obsolete as the functionality 
mentioned is now built-in.