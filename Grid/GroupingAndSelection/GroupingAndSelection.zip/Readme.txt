This example demonstrates how to select/deselect items in a particular group. When all items in a certain group are 
selected the group headers checkboxes related to these items are checked. 
If one of the items in the group is not selected the group header checkboxes should not be checked. 
In order for the algorithm to work correctly the GroupLoadMode should be set to Client.