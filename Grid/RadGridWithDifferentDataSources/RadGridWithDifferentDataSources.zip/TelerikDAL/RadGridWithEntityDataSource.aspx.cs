﻿using System;
using System.Linq;

public partial class RadGridWithEntityDataSource : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}