﻿using System;

public partial class RadGridWithLinqToSqlDataSource : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}