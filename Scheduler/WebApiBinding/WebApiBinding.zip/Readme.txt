This example demonstrates how RadScheduler can be bound to HTTP service using ASP.NET Web API. ASP.NET Web API is a framework that makes it
 easy to build HTTP services that reach a broad range of clients, including browsers and mobile devices. ASP.NET Web API is an ideal platform for
  building RESTful applications on the .NET Framework. 
RadScheduler supports all CRUD operations "Create, Read, Update, and Delete� when it is using Web Api DataBinding.

Besides Telerik dlls RadScheduler Web Api binding requires references to Newtonsoft.Json.dll, 
 System.Net.Http.Formatting.dll, System.Web.Http.dll and System.Web.Http.WebHost.dll.