This example demonstrates how to filter RadScheduler 
that is grouped by multiple respurces withth help of RadComboBox with checkBoxes so that only the checked items are shown in RadScheduler.