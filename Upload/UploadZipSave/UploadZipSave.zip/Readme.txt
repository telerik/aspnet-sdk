﻿This example demonstrates how to use RadAsyncUpload and RadZipLibrary together to create zip archive from all uploaded files. 
The arhive is then placed in the target folder.