﻿
Partial Class HelloRadEditor_skinned
    Inherits System.Web.UI.Page

End Class
