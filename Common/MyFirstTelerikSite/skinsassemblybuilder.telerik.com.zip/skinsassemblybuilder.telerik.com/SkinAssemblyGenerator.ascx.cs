﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using Telerik.Windows.Zip;

public partial class SkinAssemblyGenerator : System.Web.UI.UserControl
{
    public string DirectoryPath { get; set; }
    public string TempRootPath { get; set; }
    public string TempRootSkinPath { get; set; }
    public string TempGuid { get; set; }

    protected void Page_Load(object sender, EventArgs e)
    {
        currentYear.Text = DateTime.Now.Year.ToString();
        if (Request["download"] != null)
        {
            DownloadAssembly();
        }
    }

    protected void BtnGetAssembly_Click(object sender, EventArgs e)
    {
        string assemblyName = TbAssemblyName.Text;
        string skinName = TbSkinName.Text;

        DirectoryPath = Path.GetTempPath();
        DirectoryInfo dInfo = new DirectoryInfo(DirectoryPath);
        TempGuid = Guid.NewGuid().ToString();
        TempRootPath = string.Format("{0}{1}", dInfo.FullName, TempGuid);
        TempRootSkinPath = dInfo.CreateSubdirectory(TempGuid + "\\" + skinName).FullName;

        HttpContext.Current.Session["TempRootPath"] = TempRootPath;
        HttpContext.Current.Session["TempRootSkinPath"] = TempRootSkinPath;
        HttpContext.Current.Session["TbAssemblyName"] = assemblyName;

        if (RadAsyncUploadSkin.UploadedFiles.Count > 0)
        {
            UploadedFile file = RadAsyncUploadSkin.UploadedFiles[0];

            using (ZipArchive archive = new ZipArchive(file.InputStream))
            {
                List<ZipArchiveEntry> allEntries = archive.Entries.ToList();
                foreach (ZipArchiveEntry entry in allEntries)
                {
                    if (entry.CompressedLength == 0)
                    {
                        string path = string.Format("{0}\\{1}", TempRootSkinPath, entry.FullName);
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                            continue;
                        }
                    }

                    byte[] data = new byte[entry.Length];

                    Stream entryStream = entry.Open();
                    BinaryReader reader = new BinaryReader(entryStream);
                    reader.Read(data, 0, data.Length);

                    // When zip file is created with windows zip the folders are not got by the ZipArchive
                    if(entry.FullName.Contains("/"))
                    {
                        string path = string.Format("{0}\\{1}", TempRootSkinPath, entry.FullName.Substring(0, entry.FullName.LastIndexOf('/')));
                        if (!Directory.Exists(path))
                        {
                            Directory.CreateDirectory(path);
                        }
                    }
                    using (FileStream fs = File.Create(string.Format("{0}\\{1}", TempRootSkinPath, entry.FullName)))
                    {
                        fs.Write(data, 0, data.Length);
                    }
                }
            }

            if (RadAsyncUploadDll.UploadedFiles.Count > 0)
            {
                UploadedFile assemblyFile = RadAsyncUploadDll.UploadedFiles[0];
                using (Stream stream = assemblyFile.InputStream)
                {
                    byte[] asData = new byte[stream.Length];
                    stream.Read(asData, 0, asData.Length);
                    using (FileStream fs = File.Create(string.Format("{0}\\{1}", TempRootSkinPath, assemblyFile.FileName)))
                    {
                        fs.Write(asData, 0, asData.Length);
                    }
                }
            }

            var TelerikAssesmbly = Assembly.LoadFrom(TempRootSkinPath + "\\Telerik.Web.UI.dll");

            if (TelerikAssesmbly.GetName().Version.Revision == 35)
            {
                string url = string.Format("http://skinsassemblybuilder.telerik.com/35/Default.aspx?assemblyname={0}&skinname={1}&temppath={2}", assemblyName, skinName, TempRootSkinPath);
                Response.Redirect(url);
            }
            else if (TelerikAssesmbly.GetName().Version.Revision == 45)
            {
                string url = string.Format("http://skinsassemblybuilder.telerik.com/45/Default.aspx?assemblyname={0}&skinname={1}&temppath={2}", assemblyName, skinName, TempRootSkinPath);
                Response.Redirect(url);
            }
            else
            {
                AssemblyGenerator generator = new AssemblyGenerator(assemblyName, skinName, TempRootSkinPath);
                generator.GenerateAssembly();
                DownloadAssembly();
            }
        }
    }

    public void DownloadAssembly()
    {
        TempRootPath = HttpContext.Current.Session["TempRootPath"].ToString();
        TempRootSkinPath = HttpContext.Current.Session["TempRootSkinPath"].ToString();
        string TbAssemblyName = HttpContext.Current.Session["TbAssemblyName"].ToString();

        Response.Redirect(string.Format("Handler.ashx?rp={0}&an={1}", TempRootSkinPath, TbAssemblyName, TempRootPath));
    }
}