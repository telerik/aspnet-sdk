﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;

public class AssemblyGenerator
{
    readonly string NAMESPACE_NAME;
    public const string EXTENSIONFILE_CSS = ".css";
    private const string WEBRESOURCE_URL = "url('<%= WebResource(\"{0}\") %>')";
    private const string WEBRESOURCE_ASSEMBLY = "[assembly: WebResource(\"{0}\", \"{1}\")]";

    Dictionary<string, string> supportedFormats = new Dictionary<string, string>();
    List<string> resources = new List<string>();
    Regex correctStyleFileRegEx = new Regex(@"url[\s]*\([\s]*(?<url>[^\)]*)\)");

    AssemblyBuilder dynamicAssembly;

    public string GeneratedAssemblyName { get; set; }
    public string SkinName { get; set; }
    public string RootFolderPath { get; set; }

    public Assembly TelerikAssesmbly { get; set; }
    public Dictionary<string, string> ExeptionFiles { get; set; }

    public AssemblyGenerator(string assemblyName, string skinName,string rootFolderPath)
    {
        supportedFormats.Add(".css", "text/css");
        supportedFormats.Add(".jpg", "image/jpg");
        supportedFormats.Add(".gif", "image/gif");
        supportedFormats.Add(".png", "image/png");
        supportedFormats.Add(".ico", "image/x-icon");
        supportedFormats.Add(".cur", "image/x-icon");

        ExeptionFiles = new Dictionary<string, string>();
        ExeptionFiles.Add("RadInputManager", "Input");
        ExeptionFiles.Add("RadMonthYearPicker", "Calendar");
        ExeptionFiles.Add("RecurrenceEditor", "SchedulerRecurrenceEditor");
        ExeptionFiles.Add("ReminderDialog", "SchedulerReminderDialog");
        ExeptionFiles.Add("RadTimeView", "Calendar");

        GeneratedAssemblyName = assemblyName;
        SkinName = skinName;
        NAMESPACE_NAME = assemblyName;
        RootFolderPath = rootFolderPath;
    }

    public bool SearchedFile(string str)
    {
        foreach (var s in supportedFormats.Keys)
        {
            if (str.EndsWith(s))
            {
                return true;
            }
        }

        return false;
    }

    public void GenerateAssembly()
    {
        List<string> cssFilesPath = FindAllCssFilePaths(RootFolderPath);
        foreach (string path in cssFilesPath)
        {
            CorrectCSSFile(NAMESPACE_NAME, path);
        }

        CreateAssembly();
    }

    private List<string> FindAllCssFilePaths(string root)
    {
        return Directory.GetFiles(root, "*.*", SearchOption.AllDirectories).Select(x => Path.GetFullPath(x)).Where(s => s.EndsWith(".css")).ToList();
    }

    private List<string> FindAllEmbededFiles(string root)
    {
        return Directory.GetFiles(root, "*.*", SearchOption.AllDirectories).Select(x => Path.GetFullPath(x)).Where(s => SearchedFile(s)).ToList();
    }

    List<FileStream> streams = new List<FileStream>();
    public void CreateAssembly()
    {
        try
        {
            TelerikAssesmbly = Assembly.LoadFrom(RootFolderPath + "\\Telerik.Web.UI.dll");
        }
        catch
        {
            throw new Exception("The Telerik.Web.UI.dll cannot be found. Please make sure that you uploaded the Telerik.Web.UI.dll.");
        }

        AssemblyName aName = new AssemblyName(GeneratedAssemblyName);
        aName.Version = TelerikAssesmbly.GetName().Version;

        dynamicAssembly = AppDomain.CurrentDomain.DefineDynamicAssembly(aName, AssemblyBuilderAccess.Save, RootFolderPath);

        string str = string.Format("{0}.dll", aName.Name);
        ModuleBuilder mb = dynamicAssembly.DefineDynamicModule(str, str);

        try
        {
            foreach (string embededFilePath in this.FindAllEmbededFiles(RootFolderPath))
            {
                FileInfo fileInfo = new FileInfo(embededFilePath);
                FileStream fs = fileInfo.Open(FileMode.Open, FileAccess.Read);
                streams.Add(fs);

                ProcessEmbedingResources(mb, embededFilePath, fileInfo, fs);
            }

            GenerateClasses(aName, mb);

            dynamicAssembly.Save(string.Format("{0}.dll", aName.Name));
        }
        finally
        {
            foreach (FileStream item in streams)
            {
                item.Close();
            }
        }
    }

    private void GenerateClasses(AssemblyName aName, ModuleBuilder mb)
    {
        List<string> controlsNames = Directory.GetDirectories(RootFolderPath).Select(d => d.Remove(0, d.LastIndexOf('\\') + 1)).ToList();
        foreach (string className in controlsNames)
        {
            string radPrefix = "Rad";
            string name = className;
            if (name.ToLower() == "common")
            {
                radPrefix = string.Empty;
            }
            if (name.ToLower() == "input")
            {
                name = "InputControl";
            }
            if (name.ToLower() == "ajax")
            {
                name = "AjaxLoadingPanel";
            }
            if (name.ToLower() == "window")
            {
                name = "WindowBase";
            }
            if (name.ToLower() == "tooltip")
            {
                name = "ToolTipBase";
            }

            GenerateClass(aName, mb, className, radPrefix, name);
        }

        foreach (var key in ExeptionFiles.Keys)
	    {
            string name = key;
            string className = ExeptionFiles[key];

            GenerateClass(aName, mb, className, string.Empty, name);
	    }
    }

    private void GenerateClass(AssemblyName aName, ModuleBuilder mb, string className, string radPrefix, string name)
    {
        string typeName = string.Format("{0}.{1}", aName.Name, radPrefix + name);
        TypeBuilder tb = mb.DefineType(typeName, TypeAttributes.Public);

        ConstructorBuilder ctor0 = tb.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, Type.EmptyTypes);
        ILGenerator ctor0IL = ctor0.GetILGenerator();
        ctor0IL.Emit(OpCodes.Ldarg_0);

        Type type = tb.CreateType();
        if (name.ToLower() == "windowbase")
        {
            className = "Window";
        }
        if (name.ToLower() != "common")
        {
            Type[] typeArray = new Type[] { typeof(string), typeof(string), typeof(Type) };
            ConstructorInfo constructor = TelerikAssesmbly.GetType("Telerik.Web.EmbeddedSkinAttribute").GetConstructor(typeArray);

            object[] shortControlName = new object[] { className, SkinName, type };
            tb.SetCustomAttribute(new CustomAttributeBuilder(constructor, shortControlName));
        }
    }

    private void ProcessEmbedingResources(ModuleBuilder mb, string embededFilePath, FileInfo fileInfo, FileStream fs)
    {
        string directory = fileInfo.Directory.Name;
        string fileName = fileInfo.FullName;

        if (fileInfo.Name.StartsWith(directory + "."))
        {
            directory = "";
        }

        string resourceName = "";
        if (fileInfo.Directory.Name == SkinName)
        {
            resourceName = string.Format("{0}.{2}.{1}", GeneratedAssemblyName, fileInfo.Name, SkinName);
        }
        else
        {
            resourceName = string.Format("{0}.{2}.{3}.{1}", GeneratedAssemblyName, fileInfo.Name, SkinName, fileInfo.Directory.Name);
        }

        if (resources.Contains(resourceName))
        {
            throw new Exception("The resource with name " + resourceName + " already exists.");
        }

        resources.Add(resourceName);
        mb.DefineManifestResource(resourceName, fs, ResourceAttributes.Public);
        this.ProcessWebResourcesAttribute(dynamicAssembly, resourceName, fileInfo.Extension);
    }

    private void ProcessWebResourcesAttribute(AssemblyBuilder nAssemblyBuilder, string fileName, string key)
    {
        CustomAttributeBuilder customAttributeBuilder;

        Type[] typeArray = new Type[] { typeof(string), typeof(string) };
        ConstructorInfo constructor = typeof(WebResourceAttribute).GetConstructor(typeArray);
        if (key == ".css")
        {
            PropertyInfo[] property = new PropertyInfo[] { typeof(WebResourceAttribute).GetProperty("PerformSubstitution") };
            PropertyInfo[] propertyInfoArray = property;
            object[] item = new object[] { fileName, supportedFormats[key] };
            object[] objArray = new object[] { true };
            customAttributeBuilder = new CustomAttributeBuilder(constructor, item, propertyInfoArray, objArray);
        }
        else
        {
            object[] item1 = new object[] { fileName, supportedFormats[key] };
            customAttributeBuilder = new CustomAttributeBuilder(constructor, item1);
        }
        nAssemblyBuilder.SetCustomAttribute(customAttributeBuilder);
    }

    private void CorrectCSSFile(string styleNamespace, string cssFilePath)
    {
        string content;
        using (StreamReader streamReader = File.OpenText(cssFilePath))
        {
            content = streamReader.ReadToEnd();
        }

        string corectedContent = correctStyleFileRegEx.Replace(content, (Match match) =>
        {
            if (match.Groups.Count != 2)
            {
                return match.Value;
            }
            string str = match.Value.Replace("url('", string.Empty).Replace("')", string.Empty);
            if (str.StartsWith("<%= WebResource"))
            {
                return string.Format("url('{0}", str);
            }

            if (string.IsNullOrEmpty(str))
            {
                throw new Exception(string.Format("An Url is empty in {0}", Path.GetFileName(cssFilePath)));
            }
            if (str.StartsWith("ImageHandler.ashx"))
            {
                NameValueCollection nameValueCollection = HttpUtility.ParseQueryString(str.Replace("ImageHandler.ashx", ""));
                str = this.CombineVirtualPath(nameValueCollection["control"], nameValueCollection["file"]);
            }
            else if (str.StartsWith("../"))
            {
                str = str.Replace("../", string.Empty);
            }
            char[] chrArray = new char[] { '/' };
            string[] strArrays = str.Split(chrArray);
            if ((int)strArrays.Length < 2)
            {
                throw new Exception(string.Format("Url {0} not recognized in {1}", str, Path.GetFileName(cssFilePath)));
            }
            string formatedString = string.Format("{0}.{2}.{1}", styleNamespace, string.Join(".", strArrays), SkinName);
            return string.Format(WEBRESOURCE_URL, formatedString);

        });
        using (StreamWriter streamWriter = File.CreateText(cssFilePath))
        {
            streamWriter.Write(corectedContent);
        }
    }

    private string CombineVirtualPath(string sPath1, string sPath2)
    {
        return string.Format("{0}{1}{2}", sPath1, (char)47, sPath2);
    }
}


