﻿This demonstrates how to avoid the "Stop running this script.." error when transferring 
a big number of items all at once. The solution is to transfer the items in chunks, and the 
following code does this automatically.
